//
//  TaskTableViewCell.swift
//  TaskCoreData
//
//  Created by Lon Chandler Madsen on 7/27/21.
//

import UIKit

protocol TaskCompletionDelegate: AnyObject {
    func taskCellButtonTapped(task: Task)
}

class TaskTableViewCell: UITableViewCell {
    
    //MARK: - Outlets
    @IBOutlet weak var taskNameLabel: UILabel!
    @IBOutlet weak var completionButton: UIButton!
    
    //MARK: - Properties
    weak var delegate: TaskCompletionDelegate?
    var task: Task? {
        didSet {
            updateViews()
        }
    }
    
    //MARK: - Actions
    @IBAction func completionButtonTapped(_ sender: Any) {
        guard let task = task else { return }
        delegate?.taskCellButtonTapped(task: task)
    }
    
    //MARK: - Helper Methods
    func updateViews() {
        guard let task = task else { return }
        taskNameLabel.text = task.name
        if task.isComplete {
            completionButton.setImage(UIImage(systemName: "square.fill"), for: .normal)
        } else {
            completionButton.setImage(UIImage(systemName: "square"), for: .normal)
        }
    }
    
    
}//End of class
